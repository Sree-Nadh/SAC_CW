// styling.js - minimal style stub
