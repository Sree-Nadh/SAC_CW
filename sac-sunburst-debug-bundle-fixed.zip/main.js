// main.js - Sunburst (Debug) by SREE
(function () {
  const template = document.createElement("template");
  template.innerHTML = `
    <style>
      :host { display:block; width:100%; height:100%; }
      #plot { width:100%; height:100%; }
      #nodata {
        position:absolute; left:0; right:0; top:50%; transform:translateY(-50%);
        text-align:center; color:#666; font:13px system-ui, sans-serif;
      }
    </style>
    <div id="nodata">Bind data to render</div>
    <div id="plot"></div>
  `;
  class DebugWidget extends HTMLElement {
    constructor(){
      super();
      this._data=null;
      this.attachShadow({mode:"open"});
      this.shadowRoot.appendChild(template.content.cloneNode(true));
      this._plot=this.shadowRoot.getElementById("plot");
      this._nodata=this.shadowRoot.getElementById("nodata");
    }
    onCustomWidgetAfterUpdate(changedProps){
      if(changedProps.dataBinding) this._data=changedProps.dataBinding;
      this._render();
    }
    _render(){
      const db=this._data?.hierData;
      if(!db){this._nodata.style.display='block';this._plot.innerHTML='';return;}
      this._nodata.style.display='none';
      const dims=db.dimensions.map(d=>d.id); const measure=db.measures[0].id;
      const labels=[],parents=[],values=[],ids=[]; const sep='↳'; const map=new Map();
      const ensure=(arr)=>{const id=arr.join(sep);if(!map.has(id)){const label=arr[arr.length-1]||'Total';const parent=arr.length<=1?'':arr.slice(0,-1).join(sep);map.set(id,{id,label,parent,val:0});}return map.get(id);};
      ensure(['Total']);
      for(const r of db.data){const dimsVals=dims.map(h=>String(r[h]??'(blank)'));const v=Number(r[measure])||0;let p=['Total'];ensure(p).val+=v;for(const d of dimsVals){p=[...p,d];ensure(p).val+=v;}}
      for(const [,n] of map){labels.push(n.label);parents.push(n.parent);values.push(n.val);ids.push(n.id);}
      const trace={type:'sunburst',labels,parents,values,ids,branchvalues:'total',marker:{line:{color:'#fff',width:1}}};
      Plotly.react(this._plot,[trace],{margin:{l:10,r:10,t:10,b:10}}, {displayModeBar:false,responsive:true});
    }
  }
  customElements.define("sac-sunburst-debug", DebugWidget);
})();