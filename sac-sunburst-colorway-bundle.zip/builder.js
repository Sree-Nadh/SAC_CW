// builder.js - property editor
(function () {
  const tpl = document.createElement("template");
  tpl.innerHTML = `
    <style>
      :host { display:block; font:12px system-ui, sans-serif; padding:8px; }
      label { display:block; margin:6px 0 4px; }
    </style>
    <div>
      <label>Max depth (0 = auto)</label>
      <input id="depth" type="number" min="0" max="20" step="1"/>
      <label><input id="labels" type="checkbox"/> Show labels</label>
    </div>
  `;
  class Builder extends HTMLElement {
    constructor(){ super(); this.attachShadow({mode:"open"}); this.shadowRoot.appendChild(tpl.content.cloneNode(true)); }
    onCustomWidgetEditorPropertiesChanged(props){
      this.shadowRoot.getElementById("depth").value = props.maxDepth ?? 0;
      this.shadowRoot.getElementById("labels").checked = props.showLabels ?? true;
    }
    getEditorProperties(){
      return {
        maxDepth: Number(this.shadowRoot.getElementById("depth").value || 0),
        showLabels: !!this.shadowRoot.getElementById("labels").checked
      };
    }
  }
  customElements.define("sac-sunburst-builder", Builder);
})();