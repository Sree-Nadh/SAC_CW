// main.js - Sunburst (Plotly Colorway) by SREE
(function () {
  const template = document.createElement("template");
  template.innerHTML = `
    <style>
      :host { display:block; width:100%; height:100%; }
      #plot { width:100%; height:100%; }
      #nodata {
        position:absolute; left:0; right:0; top:50%; transform:translateY(-50%);
        text-align:center; color:#666; font:13px system-ui, sans-serif;
      }
    </style>
    <div id="nodata">Bind data to render</div>
    <div id="plot"></div>
  `;

  class SunburstWidget extends HTMLElement {
    constructor() {
      super();
      this._props = { showLabels: true, maxDepth: 0 };
      this._data = null;
      this.attachShadow({ mode: "open" });
      this.shadowRoot.appendChild(template.content.cloneNode(true));
      this._plot = this.shadowRoot.getElementById("plot");
      this._nodata = this.shadowRoot.getElementById("nodata");
    }

    onCustomWidgetAfterUpdate(changedProps) {
      if (changedProps.properties) Object.assign(this._props, changedProps.properties);
      if (changedProps.dataBinding) this._data = changedProps.dataBinding;
      this._render();
    }

    _buildPlotlyFromBinding() {
      const db = this._data?.hierData;
      if (!db || !db.data || !db.dimensions?.length || !db.measures?.length) return null;
      const dimHeaders = db.dimensions.map(d => d.id);
      const measure = db.measures[0].id;
      const sep = "↳";
      const nodeMap = new Map();
      const ensureNode = (pathArr) => {
        const id = pathArr.join(sep);
        if (!nodeMap.has(id)) {
          const label = pathArr[pathArr.length - 1] || "Total";
          const parentId = pathArr.length <= 1 ? "" : pathArr.slice(0, -1).join(sep);
          nodeMap.set(id, { id, label, parentId, value: 0 });
        }
        return nodeMap.get(id);
      };
      ensureNode(["Total"]);
      for (const row of db.data) {
        const dims = dimHeaders.map(h => String(row[h] ?? "(blank)"));
        const v = Number(row[measure]) || 0;
        let path = ["Total"];
        ensureNode(path).value += v;
        for (const d of dims) {
          path = [...path, d];
          ensureNode(path).value += v;
        }
      }
      const labels=[], parents=[], values=[], ids=[];
      for (const [, n] of nodeMap) {
        labels.push(n.label);
        parents.push(n.parentId);
        values.push(n.value);
        ids.push(n.id);
      }
      return { labels, parents, values, ids };
    }

    _render() {
      const data = this._buildPlotlyFromBinding();
      if (!data) { this._nodata.style.display = "block"; this._plot.innerHTML = ""; return; }
      this._nodata.style.display = "none";

      const trace = {
        type: "sunburst",
        labels: data.labels,
        parents: data.parents,
        values: data.values,
        ids: data.ids,
        marker: { line: { color: "#fff", width: 2 } },
        branchvalues: "total",
        hovertemplate: "%{id}<br><b>%{value}</b><extra></extra>",
        insidetextorientation: this._props.showLabels ? "auto" : "radial",
        textinfo: this._props.showLabels ? "label+value" : "none"
      };
      const md = Number(this._props.maxDepth);
      if (Number.isFinite(md) && md > 0) trace.maxdepth = md;

      const layout = {
        margin: { l:10, r:10, t:10, b:10 },
        sunburstcolorway: [
          "#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3",
          "#FF6692","#B6E880","#FF97FF","#FECB52","#8dd3c7","#ffffb3",
          "#bebada","#fb8072","#80b1d3","#fdb462","#b3de69","#fccde5"
        ],
        extendsunburstcolors: true
      };
      const config = { displayModeBar:false, responsive:true };
      Plotly.react(this._plot, [trace], layout, config);
    }
  }
  customElements.define("sac-sunburst", SunburstWidget);
})();